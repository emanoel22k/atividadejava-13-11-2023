package com.aulateste.aulateste.controlles;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import com.aulateste.aulateste.service.CompraService;
import com.aulateste.aulateste.entities.Compra;

@RestController
@RequestMapping("/api/compras")
public class CompraController {
    @Autowired
    private CompraService compraService;

    @GetMapping
    public List<Compra> listarCompras() {
        return compraService.listarCompras();
    }

    @GetMapping("/{id}")
    public Compra obterCompraPorId(@PathVariable Long id) {
        return compraService.obterCompraPorId(id);
    }

    @PostMapping
    public Compra salvarCompra(@RequestBody Compra compra) {
        return compraService.salvarCompra(compra);
    }

    @PutMapping("/{id}")
    public Compra atualizarCompra(@PathVariable Long id, @RequestBody Compra compra) {
        return compraService.atualizarCompra(id, compra);
    }

    @DeleteMapping("/{id}")
    public void deletarCompra(@PathVariable Long id) {
        compraService.deletarCompra(id);
    }
}