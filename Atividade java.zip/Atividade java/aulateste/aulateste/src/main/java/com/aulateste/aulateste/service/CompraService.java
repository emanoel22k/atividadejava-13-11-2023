package com.aulateste.aulateste.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aulateste.aulateste.repositories.CompraRepository;
import com.aulateste.aulateste.entities.Compra;

import java.util.List;


@Service
public class CompraService {
    @Autowired
    private CompraRepository compraRepository;

    public List<Compra> listarCompras() {
        return compraRepository.findAll();
    }

    public Compra obterCompraPorId(Long id) {
        return compraRepository.findById(id).orElse(null);
    }

    public Compra salvarCompra(Compra compra) {
        return compraRepository.save(compra);
    }

    public Compra atualizarCompra(Long id, Compra compraAtualizada) {
        Compra compraExistente = compraRepository.findById(id).orElse(null);

        if (compraExistente != null) {
            compraExistente.setProduto(compraAtualizada.getProduto());
            compraExistente.setQuantidade(compraAtualizada.getQuantidade());
            compraExistente.setData(compraAtualizada.getData());
            return compraRepository.save(compraExistente);
        }

        return null;
    }

    public void deletarCompra(Long id) {
        compraRepository.deleteById(id);
    }
}