package com.aulateste.aulateste.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.aulateste.aulateste.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
}