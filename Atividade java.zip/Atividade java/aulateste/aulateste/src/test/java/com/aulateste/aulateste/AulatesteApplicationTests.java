package com.aulateste.aulateste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulatesteApplicationTests {

	@Test
	void contextLoads() {
	}

}